import math
from pylab import*
import numpy as np
from scipy import integrate
#from sympy import fourier_series
#def a_integrand(f,x,n):
	#return(f*cos(n*x)

def exp1(x):   #Function defining exponential
	
	result=[]
	print(type(x))
	for elem in x:
		result.append(math.exp(elem)) #appending values to result list
	return(result)
def cos_cos(x):
	result=[]
	for elem in x:
		result.append(math.cos(math.cos(elem))) #appending values to result list
	return(result)

def cos1(x):				#pre-made math functions for vector inputs
	result=[]
	for elem in x:
		result.append(math.cos(elem)) 
	return(result)
	
def sin1(x):
	result=[]
	for elem in x:
		result.append(math.sin(elem))
	return(result)



x=np.linspace(-2*math.pi,4*math.pi,num =3000)
x1=x
#print(exp(x))
#tight_layout(pad=8.0)
subplot(3,4,1)

grid(True)
title('Plot of exp(x)')		#Plotting exp(x) true function
xlabel('x')
ylabel('exp(x)')
plot(x,exp1(x),label='exp(x)')
legend(loc='upper left')

subplot(3,4,2)
grid(True)
title('Plot of cos(cos(x))')
xlabel('x')									#Plotting cos(cos(x)) true function
ylabel('cos(cos(x))')
plot(x,cos_cos(x),label='cos(cos(x))')
legend(loc='upper left')
#now since fourier series can't exist for this function which isnt periodic we make it 2*pi periodic

size=1000

t=np.linspace(0, 2*pi, num =size) #periodic time interval
expected_exp=exp1(t)*3

expected_cos_cos=cos_cos(t)*3


subplot(3,4,3)
title('Expected Plot(semi-log) of exp(x) with f.s.  ')        #Plotting expected plots for exp(x) after Fourier series Expansion
xlabel('x')
ylabel('exp(x)')
semilogy(x,expected_exp)


subplot(3,4,4)
title('Expected Plot of cos(cos(x)) with fourier series ')		#Plotting expected plots for cos(cos(x))
xlabel('x')
ylabel('cos(cos(x))')
plot(x,expected_cos_cos)







freq_size=25
f_size=51
#f1= exp1(t)  # the truncated versions of the functions
f_exp = lambda x: math.exp(x)		#generating the exact math function
f_cos_cos= lambda x: math.cos(math.cos(x)) 		

#Fourier series for exp(x)

a0=integrate.quad(f_exp,0,2*pi,args=())[0]/(2*pi)  #dc term in fourier expansion
a=np.empty([freq_size+1,1],dtype=float)			   #defining matrix for an values
b=np.empty([freq_size,1],dtype=float)				#defining matrix for an values
coeff=np.empty([f_size,1],dtype=float)
coeff[0]=a0											#stores all coefficients
a[0]=a0

c=1
f_exp_exp=0
#Generating Fourier coefficients from Direct Integration
for i in range(1,freq_size+1):   	
	f1= lambda x,i :math.exp(x)*math.cos(i*x)			 #generating net function to be integrated
	f2= lambda x,i :math.exp(x)*math.sin(i*x)  			
	a[i]= integrate.quad(f1,0,2*pi,args=(i,))[0]/(pi)		#finding fourier coefficients an
	b[i-1]= integrate.quad(f2,0,2*pi,args=(i,))[0]/(pi)   #finding fourier coefficients bn
	coeff[c]=a[i]
	coeff[c+1]=b[i-1] #stores fourier series coefficients in result matrix
	c+=1
	


b=np.absolute(b) #making the coefficients absolute
a=np.absolute(a) 
# Fourier series for cos(cos(x))
a0_cos=integrate.quad(f_cos_cos,0,2*pi,args=())[0]/(2*pi) #dc term in fourier expansion

#n=linspace(0,freq_size+1)
a1=np.empty([freq_size+1,1],dtype=float)	#matrix having fourier series coefficients
b1=np.empty([freq_size,1],dtype=float)
coeff1=np.empty([f_size,1],dtype=float)
a1[0]=a0_cos
coeff1[0]=a0_cos

#Direct integration for cos(cos(x))
c=1
for i in range(1,freq_size+1):
	f1= lambda x,i :math.cos(math.cos(x))*math.cos(i*x)
	f2= lambda x,i :math.cos(math.cos(x))*math.sin(i*x) 
	a1[i]= integrate.quad(f1,0,2*pi,args=(i,))[0]/(pi)     #finding fourier coefficients
	b1[i-1]= integrate.quad(f2,0,2*pi,args=(i,))[0]/(pi)
	coeff1[c]=a1[i]
	coeff1[c+1]=b1[i-1]
	c+=1


b1=np.absolute(b1) #generating absoulte value of f.s. coefficients 
a1=np.absolute(a1)

n1=np.linspace(1,25,num=25)
print(n1)
print('b1',b1[0])

print('b',b[0])

subplot(3,4,5)

title('Semi-log Plot f.s values-exp(x)')		#generating semi log plot of f.s. valus of exp(x)
xlabel('n')
ylabel('Coefficent magnitude (integ)')
semilogy(a,Marker='o',color='blue',label='an')
semilogy(n1,b,Marker='o',color='red', label='bn')
legend(loc='lower left')

subplot(3,4,6)

title('Log Plot f.s values-exp(x)')				#generating log plot of f.s. valus of exp(x)
xlabel('n')
ylabel('Coefficent magnitude (integ)')
loglog(a,Marker='o',color='blue',label='an')
loglog(n1,b,Marker='o',color='red', label='bn')
legend(loc='lower left')

subplot(3,4,7)
print('bn coscos',b1)
title('Semilog Plot f.s values -cos(cos(x))')		#generating semi log plot of f.s. valus of cos(cos(x))
xlabel('n')
ylabel('Coefficent magnitude (integ)')
semilogy(a1,Marker='o',color='blue',label='an')
semilogy(n1,b1,Marker='o',color='red', label='bn')
legend(loc='upper right')

subplot(3,4,8)

title('Log Plot f.s values - cos(cos(x))')			#generating semi log plot of f.s. valus of cos(cos(x))
xlabel('n')
ylabel('Coefficent magnitude (integ)')

loglog(a1,Marker='o',color='blue',label='an')
loglog(n1,b1,Marker='o',color='red', label='bn')
legend(loc='upper right')



#Least squares method

x=np.linspace(0,2*pi,num=401) #making equally spaced x array
x=x[:-1] 	# drop last term to have a proper periodic integral size= 400
b1= exp1(x)

b2 = cos_cos(x) #finding true function values
A=np.zeros((400,51)) #allocate space for A
A[:,0] = 1 #col1 is all ones
for k in range(1,26):
	A[:,2*k-1] = cos1(k*x)   #cos(kx) column
	A[:,2*k] = sin1(k*x)     #sin(kx) column
#endfor
#print(b1)
c1= lstsq(A,b1)[0] #best fit vector for exp(x)
c2= lstsq(A,b2)[0] #best fit vector for cos(cos(x))

result_1=dot(A,c1) #finding result values for exp(x)
result_2= dot(A,c2) #finding result values for cos(cos(x))
c1_a= np.absolute(c1[::2]) #an for exp(x)
c1_b= np.absolute(c1[1::2]) #bn for exp(x)


c2_a= np.absolute(c2[::2]) #an for cos(cos(x))
c2_b= np.absolute(c2[1::2]) #bn for cos(cos(x))

subplot(3,4,9)
title('LSTSQ-f.s values(semilog) -exp(x)')
xlabel('n')
ylabel('Magnitude of coefficients')
semilogy(c1_a,Marker='o',color='green',label='an') #plotting computed an exp(x)
semilogy(n1,c1_b,Marker='o',color='blue',label='bn') #plotting computed bn exp(x)
legend(loc='upper right')

subplot(3,4,10)
title('LSTSQ-f.s values (log) - cos(cos(x))')
xlabel('n')
ylabel('Magnitude of coefficients')
loglog(c2_a,Marker='x',color='green',label='an') #plotting computed an cos(cos(x))
loglog(n1,c2_b,Marker='x',color='blue',label='bn') #plotting computed bn cos(cos(x))
legend(loc='upper right')

#show()
#close('all')







subplot(3,4,1)
#semilogy(x1,exp1(x1),label='exp(x)')
semilogy(x,result_1,color='Red',label='predicted')   #plotting predicted exp(x) semilog
legend(loc='upper left')


subplot(3,4,2)
#show()
scatter(x,result_2,color= 'Red',label='predicted')   #plotting predicted cos(cos(x)) normal
legend(loc='upper left')


#deviation for fs coefficients of exp(x)
print(c1-coeff)
net_dev1=sum(np.absolute(c1-coeff))
max_dev1=np.amax(np.absolute(c1-coeff))

print('Net deviation in coefficients for exp(x):' , net_dev1)		#printing net deviation in f.s. values of exp(x)
print('Max deviation in coefficients for exp(x):' , max_dev1)		#printing max deviation of f.s. values of exp(x)

#deviation for fs coefficients of cos(cos(x))
net_dev2=sum(np.absolute(c2-coeff1))
max_dev2=np.amax(np.absolute(c2-coeff1))

print('Net deviation in coefficients for cos(cos(x)):' , net_dev2)	#printing net deviation in f.s. values of exp(x)
print('Net deviation in coefficients for cos(cos(x)):' , max_dev2)	#printing max deviation of f.s. values of exp(x)


show() #showing all subplots







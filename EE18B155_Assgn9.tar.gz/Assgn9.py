from pylab import*
import numpy 
from scipy import signal
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D


#EXERCISE CODE

t = linspace(-pi,pi,65)
t=t[:-1]
dt = t[1]-t[0]
fmax = 1/dt #Maximum frequency ie, sampling freq.
y = sin(sqrt(2)*t) #input function
y[0]=0 # to make it antisymmetric
y= fftshift(y) # to make y start with y(t=0)
Y = fftshift(fft(y))/64.0#DFT
w = linspace(-pi*fmax,pi*fmax,65)
w = w[:-1]
figure()
subplot(2,1,1)
plot(w,abs(Y),lw=2)
xlim([-10,10])
ylabel(r"$|Y|$",size = 16)
title(r"Spectrum of $\sin\left(\sqrt{2}t\right)$")
grid(True)
subplot(2,1,2)
plot(w,angle(Y),'ro',lw=2)
xlim([-10,10])
ylabel(r'Phase of $Y$',size = 16)
xlabel(r'$\omega$',size = 16)
grid(True)
savefig('fig10-1.png')
show()

#Since we didn't get the required result, we plot sin(1.414t)
figure()
t1=linspace(-pi,pi,65);t1=t1[:-1]
t2=linspace(-3*pi,-pi,65);t2=t2[:-1]
t3=linspace(pi,3*pi,65);t3=t3[:-1]
# y=sin(sqrt(2)*t)
plot(t1,sin(sqrt(2)*t1),'b',lw=2)
plot(t2,sin(sqrt(2)*t2),'r',lw=2)
plot(t3,sin(sqrt(2)*t3),'r',lw=2)
ylabel(r"$y$",size=16)
xlabel(r"$t$",size=16)
title(r"$\sin\left(\sqrt{2}t\right)$")
grid(True)
savefig("fig10-2.png")
show()
#We realise that there is a discontinutiy in taking the current period(-pi,pi) of the function and replicating it.

#Analysis of spectrum of rect function
t= linspace(-pi,pi, num = 65)
t=t[:-1]
dt = t[1]-t[0]
fmax = 1/dt
y=t
y[0]=0
y= fftshift(y)
Y = fftshift(fft(y))/64
w = linspace(-fmax*pi,fmax*pi,num = 65)
w=w[:-1]
figure()
subplot(2,1,1)
title(r'Spectrum of box function')
semilogx(abs(w),20*log10(abs(Y)),lw=2)
ylabel('|Y|->')
xlim([1,10])
ylim([-20,0])
grid(True)
subplot(2,1,2)
plot(w,angle(Y),'ro', lw=2)
xlim([-10,10])
ylabel(r'Phase of $Y$',size = 16)
xlabel(r'$\omega$',size = 16)
grid(True)
savefig('fig10-3.png')
show()
#Hence, we see that due to the decay in the jumps at the edges of the function, the higher frequencies decay more causing supression of the peaks

# Now we introduce a Hamming window
t2= linspace(-3*pi,-pi, num = 65)
t2=t2[:-1]
t3= linspace(pi,2*pi, num = 65)
t3=t3[:-1]
y = sin(sqrt(2)*t)
n= arange(64)
wn = fftshift(0.54+0.46*cos(2*pi*n/63)) #making it in the range -pi to pi
y= (y*wn) #New function smeared with hamming window
figure()
grid(True)
title('Plot of hamming windowed function')
ylabel('y(t)*w(t)->')
xlabel('t->')
plot(t,y,'ro')
plot(t2,y,'bo')
plot(t3,y,'bo')
savefig('fig10-4.png')
show()
# Now we see the jumps have reduced

#Finding fft of the new smeared signal
# here y = y_old*hamming window
y[0]=0 # to make it antisymmetric
y=fftshift(y) # to make it in range 0-2pi
Y = fftshift(fft(y))/64.0 #DFT of new signal
w = linspace(-fmax*pi,fmax*pi,num=65) #fmax = 1/dt of t-timescale
w= w[:-1]
figure()
subplot(2,1,1)
title('Spectrum of sin($sqrt(2)*t$)*w(t)')
grid(True)
ylabel('|Y| ->')
plot(w,abs(Y),lw=2)
xlim([-8,8])
subplot(2,1,2)
grid(True)
ylabel('Phase->')
xlabel('$\omega$ ->')
plot(w,angle(Y),'ro')
xlim([-8,8])
savefig('fig10-5.png')
show()

#We do the same this time with N=256

t= linspace(-4*pi,4*pi,num=257)
t=t[:-1]
dt = t[1]-t[0]
fmax=1/dt
y = sin(sqrt(2)*t)
#defining hamming window
n = arange(256)
wn = fftshift(0.54 +0.46*cos(2*pi*n/255)) #Using hamming window
y_new = y*wn
y_new[0]=0
y_new= fftshift(y_new)
Y_new = fftshift(fft(y_new))/256
#defining freq. scale
w =linspace(-fmax*pi,fmax*pi,num= 257)
w=w[:-1]
#Plotting spectrum
figure()
subplot(2,1,1)
title('Spectrum of sin($sqrt(2)*t$)*w(t) with N=256')
grid(True)
ylabel('|Y| ->')
plot(w,abs(Y_new),'b',w,abs(Y_new),'bo')
xlim([-4,4])
subplot(2,1,2)
grid(True)
ylabel('Phase->')
xlabel('$\omega$ ->')
plot(w,angle(Y_new),'ro')
xlim([-4,4])
savefig('fig10-6.png')
show()



#SPECTRUM FOR cos^3(wot)

#without hamming window

#Here, we'll use 256 samples for higher accuracy

y=pow(cos(0.86*t),3)
y= fftshift(y) # 0-8pi range
Y = fftshift(fft(y))/256
# w is defined earlier.
#Plotting
figure()
subplot(2,1,1)
title('Spectrum of $cos(w0t)^3$ without windowing')
ylabel('|Y| ->')
plot(w, abs(Y),lw=2)
xlim([-4,4])
grid(True)
subplot(2,1,2)
ylabel('Phase->')
xlabel('$\omega$->')
plot(w,angle(Y),'bo')
xlim([-4,4])
grid(True)
savefig('fig10-q2_a.png')
show()
#Using the hamming window
y=pow(cos(0.86*t),3)
n = arange(256)
wn = fftshift(0.54 +0.46*cos(2*pi*n/255))  #Using hamming window
y_new= y*wn
y_new = fftshift(y_new)
Y_new= fftshift(fft(y_new))/256
#Plotting
figure()
subplot(2,1,1)
title('Spectrum of $cos(w0t)^3$ with windowing')
ylabel('|Y| ->')
plot(w, abs(Y_new),lw=2)
xlim([-4,4])
grid(True)
subplot(2,1,2)
ylabel('Phase->')
xlabel('$\omega$->')
plot(w,angle(Y_new),'bo')
xlim([-4,4])
grid(True)
savefig('fig10-q2_b.png')
show()


#Question 3-Estimation of w0 and delta

#Generating a signal cos(w0t+delta)
# 0.5<w0<1.5 , 0< delta< 2pi 
#Defining a 128 length time vector
t = linspace(-2*pi, 2*pi, num = 129)
t=t[:-1]
dt = t[1]-t[0]
fmax = 1/dt #Maximum frequency ie, sampling freq.

w0 = numpy.random.uniform(0.5,1.5) #randomly choosing w0 and delta in the given range
delta = numpy.random.uniform(0,2*pi)
y = cos(w0*t+delta)
print('w0:',w0)
print('delta:',delta)
n = arange(128)
wn = fftshift(0.54 +0.46*cos(2*pi*n/127))
y_new = y*wn			#Using hamming window
y_new=fftshift(y_new)
Y_new = fftshift(fft(y_new))/128 # Finding DFT
w = linspace(-pi*fmax,pi*fmax,129)
w=w[:-1]
figure()
subplot(2,1,1)
title('Spectrum of $cos(w0t+delta)$ with windowing')
ylabel('|Y| ->')
plot(w, abs(Y_new),lw=2)
#calculating w0_estimated
w0_est=w[numpy.argmax(abs(Y_new))] #finding the frequency at the maxima
xlim([-5,5])
grid(True)
subplot(2,1,2)
ylabel('Phase->')
xlabel('$\omega$->')
plot(w,angle(Y_new),'b')
xlim([-5,5])
grid(True)
#calculating delta_est
delta_est=angle(Y_new)[numpy.argmax(abs(Y_new))] #calulating phase of Y at freq. of maxima
if(w0_est<0): # if maxima is in -ve side
	w0_est*=-1
	delta_est*=-1

if(delta_est >= 2*pi):  # in case the phase crosses 2*pi
	delta_est-= 2*pi 
print('w0 estimated:',w0_est)
print('delta estimated:',delta_est)
savefig('fig_est1.png')
show()



#Question4-
# Now we add some white gaussian noise to the original signal
y2= cos(w0*t+delta) + 0.1*randn(128)
y_new2 = y2*wn
y_new2=fftshift(y_new2)
Y_new2 = fftshift(fft(y_new2))/128
#Plotting
figure()
subplot(2,1,1)
title('Spectrum of $cos(w0t+delta) + noise$ with windowing')
ylabel('|Y| ->')
plot(w, abs(Y_new2),lw=2)
print('Total error in Magnitude Spectrum with noise:',sum(abs(Y_new-Y_new2))) #Printing total error in magnitude with and without noise
xlim([-5,5])
grid(True)
subplot(2,1,2)
ylabel('Phase->')
xlabel('$\omega$->')
plot(w,angle(Y_new2),'b')
xlim([-5,5])
grid(True)
#Estimating parameters
w0_est2=w[numpy.argmax(abs(Y_new2))] #finding frequency of maxima and the corresponding phase at that point
delta_est2=angle(Y_new2)[numpy.argmax(abs(Y_new2))]

if(w0_est2<0): # if the maxima is in the -ve side
	w0_est2*=-1
	delta_est2*=-1
	
if(delta_est2 >= 2*pi):  # in case the phase crosses 2*pi
	delta_est2-= 2*pi 


print('w0_est (with noise):',w0_est2)
print('delta_est (with noise)',delta_est2)
savefig('fig_est2.png')
show()

#Question 5
t=linspace(-pi,pi,num=1025)
t=t[:-1]
dt=t[1]-t[0]
fmax = 1/dt
y1 = cos(16*(1.5+t/(2*pi))*t)
#Here there's no need for a hamming window since, it's almost continuous at the edges of the time interval anyway
y= fftshift(y1)
Y = fftshift(fft(y))/1024
w= linspace(-fmax*pi,fmax*pi,num=1025)
w=w[:-1]
figure()
subplot(2,1,1)
plot(w,abs(Y),lw=2)
xlim([-60,60])
ylabel(r"$|Y|$",size = 16)
title(r"Spectrum of cos(16(1.5 + t/(2$\pi$))t)")
grid(True)
subplot(2,1,2)
plot(w,angle(Y),'ro',lw=2)
xlim([-60,60])
ylabel(r'Phase of $Y$',size = 16)
xlabel(r'$\omega$',size = 16)
grid(True)
savefig('fig10-q5.png')
show()

#Question6
y_arr = numpy.split(y1,16) #Splitting input signal into 16 sets

#calculating dft for each of the 16 sets having 64 samples
#Here we need to use a hamming window for each to obtain a good dft for each set
c=0
Y =[]
w_arr= linspace(-fmax*pi,fmax*pi,num=65)
w_arr=w_arr[:-1]

for y_i in y_arr:
	#y_i is of length 64
	n=arange(64)
	wn = fftshift(0.54+0.46*cos(2*pi*n/63)) #making it in the range -pi to pi
	y_i=y_i*wn
	y_i=fftshift(y_i)
	Y_i=fftshift(fft(y_i))/64
	Y_i = numpy.reshape(Y_i,(64,1))  #making it a column array
	if(c==0):
		Y=Y_i    #initial condition of Y
		
	else:
		Y = numpy.concatenate((Y,Y_i),axis=1) #concatenating all columns subsequently
	c+=1
	

t_arr=linspace(-pi,7*pi/8,num=16)
w_arr= linspace(-fmax*pi,fmax*pi,num=65)
w_arr=w_arr[:-1]
fig = plt.figure()
ax = fig.add_subplot(111, projection='3d')
W,T = numpy.meshgrid(w_arr,t_arr)
title('Surface plot of dft (|Y|) with time and freq.')
xlabel('$\omega$ ->')
ylabel('time->')
surf =ax.plot_surface(W,T,abs(Y).T, cmap=cm.jet,rstride=1,cstride=1) #Plotting surface plot.
fig.colorbar(surf, shrink=0.5, aspect=5)
plt.show()











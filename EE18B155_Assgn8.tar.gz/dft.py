from numpy import *
from pylab import *
#checking fft and ifft accuracy
x=rand(100)
X=fft(x)
y=ifft(X)
c_[x,y]
print (abs(x-y).max()) #printing error due to computations

#producing magnitude and phase plots
x= linspace(0,2*pi,num=128)  
y= sin(5*x)
Y = fft(y)  #Plotting fft of sin(5x) directly
figure()
subplot(2,1,1)
plot(abs(Y), lw=2)   #Plotting absolute value magnitude
ylabel(r"$|Y|$", size = 16)
title(r"Spectrum of $\sin(5t)$")
grid(True)
subplot(2,1,2)
plot(unwrap(angle(Y)),lw=2) #Plotting phase
ylabel(r"Phase of $Y$",size = 16)
xlabel(r"$k$",size = 16)
grid(True)
savefig("fig9-1.png")


#Plotting right figures after shifting and scaling amplitude

x=linspace(0,2*pi,num=129)
x=x[:-1] #Removing last element to avoid repetition.
y= sin(5*x)
Y = fftshift(fft(y))/128.0 #Plotting after taking fft and shifting the graph in addition to scaling
w= linspace(-64,63,num=128) #Rearranged our k axis so that the indices are aligned for magnitude and phase plots
figure()
subplot(2,1,1)
plot(w,abs(Y),lw=2)
xlim([-10,10])  #Limiting set of frequencies shown
ylabel(r"Spectrum of $\sin(5t) (Corrected)$")
grid(True)
subplot(2,1,2)
plot(w,angle(Y),'ro',lw=2)
ii= where(abs(Y)>1e-3) #identifying points with significant value in magnitude plot
plot(w[ii],angle(Y[ii]),'go',lw=2) #Plotting phase of only those values which have a significant magnitude
xlim([-10,10])
ylabel(r"Phase of $Y$",size=16)
xlabel(r"$k$",size=16)
grid(True)
savefig('fig9-2.png')



#plotting fft of (1+0.1cos(t))cos(10t)
figure()
subplot(2,1,1)
t= linspace(0,2*pi,num=129)
t=t[:-1]
y= (1+0.1*cos(t))*cos(10*t)
Y = fftshift(fft(y))/128.0  #Computing fft of y
w = linspace(-64,63,num=128)
xlim([-15,15])
ylabel(r"$|Y|$",size=16)
title(r"Spectrum of $\left(1+0.1\cos\left(t\right)\right)\cos\left(10t\right)$")
plot(w,abs(Y),lw=2)
grid(True)
subplot(2,1,2)
plot(w,angle(Y),'ro',lw=2)
xlim([-15,15])									#Plotting
ylabel(r"Phase of $Y$",size=16)
xlabel(r"$\omega$",size=16)
grid(True)
savefig('fig9-3.png')


#Plotting the fft of (1+0.1cos(t))cos(10t) given higher resolution of frequency and same sampling frequency

figure()
t= linspace(-4*pi, 4*pi,num= 513) #stretching the time axis with the same sampling frequency
t=t[:-1] #removing the last element
y = (1+0.1*cos(t))*cos(10*t)
Y = fftshift(fft(y))/512.0 #inc resolution of freq resp.
w = linspace(-64,64,num=513) #inc resolution of freq
w=w[:-1]
subplot(2,1,1)
plot(w,abs(Y),lw=2)
xlim([-15,15])
ylabel(r'$|Y|$',size=16)
title(r"Spectrum of $\left(1+0.1\cos\left(t\right)\right)\cos\left(10t\right)$")
grid(True)
subplot(2,1,2)
plot(w,angle(Y),'ro',lw=2)
xlim([-15,15])									#Plotting
ylabel(r'Phase of $Y$',size=16)
xlabel(r'$\omega$',size=16)
grid(True)
savefig('fig9-4.png')



#Generating fft for sin(t)^3 

figure()
t= linspace(-8*pi , 8*pi, num = 1025) #keeping the big sample size for good resolution
t= t[:-1] 				
y= (sin(t))**3
Y = fftshift(fft(y))/1024.0 #finding fft and shifting 
w = linspace(-64,64,num=1025)
w= w[:-1]
subplot(2,1,1)
plot(w, abs(Y),lw =2)
xlim([-20,20]) #limiting freqs.
ylabel(r'$|Y|$',size=16)
title(r"Spectrum of $sin(t)^3$")
grid(True)													#Plotting
subplot(2,1,2)
plot(w,angle(Y),'ro',lw=2)
xlim([-20,20])
ylabel(r'Phase of $Y$',size=16)
xlabel(r'$\omega$',size=16)
grid(True)
savefig('fig9-5.png')

#Generating fft for cos(t)^3

figure()
t = linspace(-8*pi, 8*pi , num = 1025)
t = t[:-1]
y= (cos(t))**3
Y = fftshift(fft(y))/1024.0 #finding fft and shifting
w = linspace(-64,64,num=1025)
w = w[:-1]
subplot(2,1,1)
plot(w, abs(Y),lw = 2)
xlim([-20,20])
ylabel(r'$|Y|$',size = 16)
title(r'Sprectrum of $cos(t)^3$')
grid(True)
subplot(2,1,2)
plot(w, (angle(Y)), 'ro', lw=2)								#Plotting
xlim([-20,20])
ylabel(r'Phase of $Y$', size = 16)
xlabel(r'$\omega$',size= 16)
grid(True)
savefig('fig9-6.png')

#Generating fft for cos(20t+5cos(t))
figure()
t= linspace(-4*pi,4*pi, num =513)
t=t[:-1]
y = cos(20*t+5*cos(t))
#y = cos(20*t)*cos(5*cos(t)) -sin(20*t)*sin(5*cos(t))
Y = fftshift(fft(y))/512.0
w = linspace(-64,64,num=513)
w = w[:-1]
subplot(2,1,1)
plot(w,abs(Y),lw=2)
xlim([-40,40]) #limiting frequencies
ylabel(r'$|Y|$',size = 16)
title(r"Spectrum of $cos(20t+5cos(t))$")
grid(True)
subplot(2,1,2)
ii = where( abs(Y)>1e-3)
plot(w[ii],(angle(Y[ii])),'ro',lw=2)				#Plotting phase for only points with high magnitude.
xlim([-40,40])	
ylabel(r'Phase of $Y$',size=16)
xlabel(r'$\omega$',size=16)
grid(True)
savefig('fig9-7.png')

#Generating fft for exp(-t^2/2)
figure()
t= linspace(-524288*pi/2,524288*pi/2, num =67108864/2+1) #Setting the computed scale for a 1e-6 accuracy.
t=t[:-1]
t=ifftshift(t) # this is done to prevent a sawtooth phase plot from computatinal errors
y = exp(-(t**2)/2.0)
Y = (fftshift(fft(y)))/(67108864.0/2)
w = linspace(-64,64,num=67108864/2+1) #Setting the computed scale for a 1e-6 accuracy.
w = w[:-1]
subplot(2,1,1)  

print('time after ifft shift',t)

print('accuracy:',w[1]-w[0]) 	#Printing accuracy of the scale.
ii = where( abs(Y)>1e-7)      

plot(w,abs(Y),lw=2)	
xlim([-10,10]) #limiting frequencies
ylabel(r'$|Y|$',size = 16)
title(r"Spectrum of $exp(-t^2/2)$")
grid(True)
subplot(2,1,2)
plot(w[ii],(angle(Y[ii])),lw=2)
xlim([-10,10])							#Plotting
ylabel(r'Phase of $Y$',size=16)
xlabel(r'$\omega$',size=16)
grid(True)
savefig('fig9-8.png')
show()




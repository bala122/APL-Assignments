
# script to generate data files for the least squares assignment
from pylab import *
import numpy as np
import scipy.special as sp

def g(t,A,B):
	return(A*sp.jn(2,t)+B*t)

N=int(101) # no of data points
k=int(9)
# no of sets of data with varying noise
# generate the data points and add noise
t=linspace(0,10,N)

t2= linspace(0,10,21) #generating a scale of every fifth data point
# t vector

#EXACT FUNCTION
y=1.05*sp.jn(2,t)-0.105*t # f(t) vector
Y=meshgrid(y,ones(k),indexing='ij')[0] # make k copies
scl=logspace(-1,-3,k) # noise stdev

n=dot(randn(N,k),diag(scl)) # generate k vectors, n is noise
#FUNCTION WITH NOISE
#print(n)

yy=Y+n  #adding noise

savetxt("fitting.dat",c_[t,yy])
time= np.empty([N,1],dtype=np.float64 )
data=np.empty([N,k],dtype=float)  #stores data from file
noise=np.empty([N,k], dtype=float)
noise=n #stores noise in data as numpy array

with open("fitting.dat","r") as f:
	lines= f.readlines()
	i=0
	for line in lines:       #Reading data into a matrix
		j=0
		time[i]= line.split()[0]
		for x in line.split()[1:len(line)]:
			data[i][j]=(x)
			j+=1
		i+=1
		
print("done")


#print(size(time))
#print(time)

rms_noise=[0]*k
		
i=0
for n in noise.T:  #101 columns
	rms_noise[i]=(sqrt(mean(square(n))))  #computing average noise
	i+=1

c=0
set('FontSize')

xlabel(r'$t$',size=20)
ylabel(r'$f(t)+n$',size=20)
title(r'Plot of the data to be fitted')

grid(True)
for column in data.T:	#Plotting the data with different kinds of noises
	subplot(2,2,1)
	title(r'')
	plot(time,column, label= 'Noise_avg: '+str(rms_noise[c]))
	c+=1

legend(loc='lower left',fontsize=9)
subplot(2,2,2)
col1=data.T[0]
stdev = np.std(col1) #computing std. deviation
title(r'Plot using Error-bars')
xlabel(r'$t$',size=20)
ylabel(r'$f(t)$',size=20)
errorbar(t[::5],col1[::5],stdev,fmt='ro',label='noisy function') #making the error bar plot
plot(t,y,label='exact function') #plotting the exact function with no noise
legend(loc='lower right',fontsize=9)

A=1.05 # true parameters defining original data
B=-0.105
# PLOTTING ESTIMATE FUNCTION GIVEN A,B
subplot(2,2,3)
title('Plot using the function g(t,A,B)')
plot(t,g(t,A,B))


J_col=np.empty([N,1],dtype=float) #vector storing values of bessel function
g_col=np.empty([N,1],dtype=float) #vector storing values of the estimating function
for i in range(N):
	J_col[i]=sp.jn(2, t[i]) 

M= c_[J_col,t] #matrix having bessel function and its time values 
p= np.array([[A],[B]]) # stores the parameters

g_col=dot(M,p)  #storing dot product in a column vector
g_test=np.empty([N,1],dtype=float) #generating output from pre-defined function
g_test=g(time,A,B) 
if(g_col.all()==g_test.all()): #checking if the matrix eqn. matches with the function output
	print('yes')

col_1= data.T[0] #stores 1st column of data
#print(col_1)
col_2= data.T[1] #stores 2nd column of data
A_lis= linspace(0.0,2.0,num=21) #make list of A values Ai - 21 values
B_lis= linspace(-0.2,0.0,num=21)#make list of B values Bj - 21 values

A_mesh,B_mesh = np.meshgrid(A_lis,B_lis)
#A_mesh=A_mesh.T
#B_mesh=B_mesh.T # because the indexing is done different from here in meshgrid function
epsilon= np.empty([21,21],dtype=float)
# Here only column 1 of data is being used 
for i in range(21):
	for j in range(21):
		for l in range(N):
			
			epsilon[i][j]+=  ( pow( (col_1[l] - g( t[l],A_lis[i],B_lis[j])),2) /N) #computing epsilon


subplot(2,3,4)

title('Contour plot of epsilon(i,j)',size=16)
xlabel('A',size=16)
ylabel('B',size=16)
cp=contourf( A_mesh, B_mesh, epsilon) #making a contour plot of epsilon vs A,B
colorbar(cp)
par_est, resid, rank, sig = lstsq(M, col_1) # returns best estimate of A,B given noise in col1

err_est_A=np.empty([k,1] , dtype=float)#error in estimate of A
err_est_B=np.empty([k,1] , dtype=float)#error in estimate of B
for i in range(k):
	dat_col=data.T[i] #stores kth col of data
	est_par,resid,rank,sig= lstsq(M, dat_col) #finding estimates
	err_est_A[i]= pow((est_par[0]-A ),2)    # calculates ms error in parameters 
	err_est_B[i]= pow((est_par[1]-B ),2)
	

subplot(2,3,5)
title('Relation between error in estimate and noise')
xlabel('RMS Average Noise',size=16)
ylabel('MS Error in estimate',size=16)
plot(rms_noise,err_est_A)   #plots error in A estimate vs noise
plot(rms_noise,err_est_B)
legend(loc='upper right', fontsize=10)
#show()
subplot(2,3,6)
title('Relation between error in estimate and noise-log scale')
xlabel('RMS Average Noise',size=16)
ylabel('MS Error in estimate',size=16)
legend(loc='upper right', fontsize=10)
loglog(rms_noise,err_est_A)
loglog(rms_noise,err_est_B)  #plots the log plot of estimate error with noise
show()







import scipy.signal as sp
import numpy
import math
from scipy import* 
from pylab import*
F_s_Num= poly1d([1,0.5]) 
F_s_Den=poly1d([1,1,2.5]) 
H_Den = poly1d([1,0,2.25])
H_num=poly1d([1])
H_T= sp.lti(H_num,H_Den)
#Now we have the transfer function H(s)
t= np.linspace(0,50,501)

#First case
u=(cos(1.5*t))*exp(-0.5*t)
t,y,svec= sp.lsim(H_T,u,t) #simulating convolution

subplot(3,3,1)
xlabel('t->')
ylabel('x(t)')
title('output x(t) Single spring system-')
plot(t,y)

#Second Case
u_new = (cos(1.5*t))*exp(-0.05*t)
t,y_new,svec= sp.lsim(H_T,u_new,t) #simulating convolution

subplot(3,3,2)
xlabel('t->')
ylabel('y(t)')
title('Spring system output plot( smaller decay)')
plot(t,y_new)

#Varying frequency in second case
freq= [1.4,1.45,1.5,1.55,1.6] #step size 0.05
i=3
for w in freq:
	u_i = (cos(w*t))*exp(-0.05*t)
	t,y_i,svec= sp.lsim(H_T,u_i,t) #simulating convolution
	subplot(3,3,i)
	itr=str((i-2))
	print(w)
	xlabel('t->')
	ylabel('y'+itr+'_(t)')
	title('iteration:'+itr)
	plot(t,y_i) #plotting graph for each iteration
	i+=1 

# Coupled springs
t2= np.linspace(0,20,num=50)
# initial conditions- x(0)=1 , y(0)=0 ,dx/dt |t=0 = 0, dy/dt |t=0 = 0

#after substituting the first eqn in the second, we get
# x(4th derivative) + 3* x(2nd derivative) =0

#Now using uinilateral laplace with initial conditions we get X(s) as:

X_num= poly1d([1,0,2,0])
X_den= poly1d([1,0,3,0,0])
X_T= sp.lti(X_num,X_den) #Stores the transfer function

#using sp.impulse to find x(t)
subplot(3,3,8)
title('x(t) for coupled spring')
xlabel('t(s)->')
ylabel('x(t)')
t,x =sp.impulse(X_T,None,linspace(0,20,501)) #calculating impulse response
plot(t,x)

#similarly we obtain an equation in y(t) as:
# y(4th derivative) + 3* y(2nd derivative) =0 , however initial conditions different from x(t)
#We obtain Y(s) as the following:
Y_num= poly1d([2,0])
Y_Den= poly1d([1,0,3,0,0])
Y_T = sp.lti(Y_num,Y_Den) #calculating the transfer function -Y(s)
subplot(3,3,9)
title('y(t) for coupled spring')
xlabel('t(s)->') 
ylabel('y(t)')
t,y= sp.impulse(Y_T,None,linspace(0,20,501)) #calculating impulse response
plot(t,y) #plotting outputs



#Two port network transfer function
H1_den=poly1d([1e-12,1e-4,1])
H1_num=poly1d([1])
H1_T= sp.lti(H1_num,H1_den)
w,S,phi= H1_T.bode()  #obtaining bode plot data
figure()
subplot(2,2,1)
title('Magnitude plot')
xlabel('w->')
ylabel('dB->')
semilogx(w,S)  #Magnitude plot
subplot(2,2,2)
xlabel('w->')
ylabel('phase(deg) ->')
title('Phase plot')
semilogx(w,phi) #Phase plot

t3= np.linspace(0,30e-6,num=30)
t4= np.linspace(30e-6,10e-3,num=400)
t5= np.linspace(0,10e-3,num=10000)
#t3=np.concatenate((t3,t4),axis=0)
figure()
v_i3=cos((1e3)*t5)-cos((1e6)*t5) #input signal
t5,y,svec= sp.lsim(H1_T,v_i3,t5) #simulating convolution
title('Full variation(0-10ms)')
xlabel('t-> (ms)')
ylabel('v(t)')
plot(t5,y) #plotting output signal
show()
 

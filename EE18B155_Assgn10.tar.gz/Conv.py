from scipy import signal
from pylab import*
import numpy as np
import csv
import string

fir_coeff=[]
with open('h.csv') as fir:
	csv_read = csv.reader(fir)
	for i in csv_read: 					#EXTRACTING COEFFICIENTS
		fir_coeff.append(float(i[0]))
#print(fir_coeff)
w,h=signal.freqz(fir_coeff) 			#Finding frequency response

figure()
subplot(2,1,1)
title('Spectrum of FIR filter')
ylabel('|H|->')							#Plotting magnitude and phase response
plot(w,abs(h))
grid(True)
subplot(2,1,2)
ylabel('Phase->')
plot(w,unwrap(angle(h)),'bo')
grid(True)
xlabel('$\omega$->')
show()

n= linspace(1,1024,num=1024)
x = cos(0.2*pi*n) + cos(0.85*pi*n)  #input signal 1024 samples
figure()
subplot(2,1,1)
title('Input signal')						#Plotting input signal
ylabel('x(n)')
xlabel('n->')
plot(n,x)
#xlim([0,100])
grid(True)

#Applying linear convolution
y = np.convolve(x,fir_coeff)
n2= linspace(1,1024,num=1035)
subplot(2,1,2)
title('Output signal (linear convolution)')						#Plotting output signal
ylabel('y(n)')
xlabel('n->')
plot(n2,y)
grid(True)
show()

#Using circular convolution


fir_coeff= np.array(fir_coeff) #Converting to a numpy array
fir_z= np.concatenate(( fir_coeff, np.zeros(( 1 , len(x)-len(fir_coeff)  ))[0] ), axis=0) #Zero padding the filter sequence
y1 = np.fft.ifft(np.fft.fft(x)*np.fft.fft(fir_z)  ) #Finding the output of the filter
figure()
subplot(2,1,1)
title('Filtered signal(with circular conv.)')						#Plotting output signal
ylabel('y(n)')
xlabel('n->')
plot(n,y1)
#xlim([1,100])
grid(True)


#Performing linear convolution and aliasing to obtain a net circular convolution output

#First dividing x(n) into sets of 'L' samples
P=12
N=128
L=N-P+1
x_s=[]
for i in range((int)(1024/L)):
	x_L=(x[L*(i) : L*(i+1) : 1])
	#Padding with zeros initially to obtain length N
	x_N=np.concatenate(( np.zeros(P-1), x_L  ))
	x_s.append(x_N)
#Obtaining the last remaining samples of x and zero padding them
x_f= (x[ (int)(1024/L) * L : 1024:1])
x_s.append( np.concatenate(( np.zeros(N-len(x_f)) , x_f  )))

#Padding h(n) to length N
fir_coeff = np.concatenate((  fir_coeff, np.zeros(N-P) )) 

y_s=[]
for x_i in x_s:
	X_i= np.fft.fft(x_i) #finding fft of x_i
	H=np.fft.fft(fir_coeff)
	#computing linear convolution with taking an appropriate N value in circular convolution
	Y_i= X_i*H
	y_i=np.fft.ifft(Y_i)
	y_s.append(y_i)

#Now that we have y_s we need to stitch the output appropriately
y_1= np.array(y_s[0]) #first sequence
y_l=np.array(y_s[-1]) #final sequence
y_1[0:P-1]+= y_l[-(P-1):] #adding first P-1 values with last P-1 values of last convolution
y_f=y_1[:-(P-1)]		#This is the first right o/p sequence 

num=(int)(1024/L) #no. of sections
for i in range(1,num+1):
	y_i= np.array(y_s[i])
	y_prev= np.array(y_s[i-1])
	y_i[0:P-1]+= y_prev[-(P-1):] #adding last P-1 values of previous convolution with first P-1 values of current
	y_f= np.concatenate(( y_f,y_i[:-(P-1)] )) #Discarding last P-1 values now and stitching


n4= linspace(1,1024,num= len(y_f))
subplot(2,1,2)
title('Filtered signal(using section wise linear convolution)')	 	#Plotting output signal
ylabel('y(n)')
xlabel('n->')
plot(n4,y_f)
#xlim([1,100])
grid(True)
show()

 
#Correlation output with Zadoff-Chu sequence 


#importing sequence

zad_seq=[] #Stores the sequence
with open('x1.csv') as zad:
	zad_r = csv.reader(zad)
	for i in zad_r:
		x=i[0].replace(" ","")
		x=x.replace("i","j")			#Reading zadaff chu sequence
		zad_seq.append(complex(x))

zad_seq =np.array((zad_seq))

b_n= zad_seq
a_n=np.roll(b_n,5) #b_n cyclically shifted by 5
A=np.fft.fft(a_n)		#Compyting dft
B=np.fft.fft(b_n)
Y= A*np.conj(B)
y= np.fft.ifft(Y)	#correlated sequence

figure()
title('Spectrum of auto-correlation of ZadChu sequence')
ylabel('|y(n)|->')							#Plotting output sequence
xlabel('n->')
plot(abs(y))
grid(True)
show()



	
	
	
	
	
	
	
	
	
	
	
	
	

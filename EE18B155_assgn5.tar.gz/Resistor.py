from pylab import*
import mpl_toolkits.mplot3d.axes3d as p3
import numpy as np
import matplotlib.pyplot as plt
import math
Nx = int(25) #size along x
Ny = int(25) #size along y

#for calculating stopping conditions values taken-
#B_err= -0.014197841518659575 #  half_life^-1
#A_err= 0.024128344122630076 
threshold=1e-8

radius =8 #radius of the central lead
Niter = int(1500) #no. of iterations to perform
N_break=Niter
phi = np.zeros([Ny,Nx],dtype=float) 	#initializing potential matrix to zero
#print(phi)
x=np.linspace(-12,12,num=25)		#Generating x array
y=np.linspace(12,-12,num=25)		#Generating y array
Y,X = meshgrid(y,x)					#Making meshgrid of x and y coordinates
Y_org=Y.copy()								#Stores original values of Y
X_org=X.copy()								#Stores original values of X
b=np.where(np.multiply(X,X)+np.multiply(Y,Y)<=8*8) #making matrix of indices of points in the 8 unit circle
ii=b
#Making 1V potential for the central circle of radius 8 units
phi[ii]=1
phi_org = phi.copy()
subplot(2,2,1)
xlabel('x')
ylabel('y')
title('Contour plot of initial potential') #plotting 1V potential
scatter(X,Y,phi.transpose(),color='red',marker='o',linewidth=3)  #plotting the 1V points with red
contour(X,Y,phi.transpose())
#show()
#Updating potential values and finding error in each iteration
oldphi=phi.copy() 						#Stores original values of Phi

errors1= np.zeros([500,1])
errors2= np.zeros([1000,1])
errors = np.zeros([Niter,1])

#FOR LOOP TO UPDATE POTENTIAL


for k in range(Niter):
	oldphi=phi.copy()
#updating phi everytime
	phi[1:-1,1:-1] = 0.25*(phi[1:-1,0:-2] +phi[1:-1,2:] +phi[0:-2,1:-1] +phi[2: , 1:-1])  #updating all interior elements of phi
	
#Updating boundary conditions
	
	# d(phi)/dn is zero on left side
	phi[1:-1,0]=phi[1:-1,1] 
	# d(phi)/dn is zero on right side
	phi[1:-1,Nx-1]=phi[1:-1,Nx-2]
	# d(phi)/dn is zero on top side
	phi[0, 1:-1 ] = phi[1, 1:-1 ]
	
	
	#for central portion
	phi[ii]=1
	
	#Finding error b/w iterations
	errors[k] = (abs(phi-oldphi)).max()
	#print('error:',errors[k])
	if(k<500):
		errors1[k] = errors[k]
	if(k>=500):
		errors2[k-500] = errors[k]
		#print(phi)
	
#Stopping condition and calulating half life ONLY IF k>=500
	
		n2_d= np.linspace(501,k+1,num=	(k+1)-500)					#dynamic changing size n2
		#errors2_d= np.zeros((k+1)-500) 								#dynamic changing error matrix
		errors2_d= errors[500:k+1]
		print(errors2_d)
		ln_err2_d= [math.log(i) for i in errors2_d] #finding log values of error2
		
		print('size n2 ,err2',size(n2_d),size(ln_err2_d))
		param2_d=  np.polyfit(n2_d,ln_err2_d,1)  #getting a,b values for y= ax +b
		A_d=  math.exp(param2_d[1])
		B_d=  param2_d[0] 						#calculating dynamic values of A and B
		error_net= abs( -A_d*math.exp(B_d*(k+0.5))/B_d) # stores error from true steady state value of phi
		print('error_net:',error_net)
		if(error_net<threshold):
			N_break=k 
		
			#print('k',k)
			break 				#if error is less than threshold break
	

#ERROR PLOTTING 



#HERE WE ARE ASSUMING IT DOESN'T BREAK OUT BEFORE 500 ITERATIONS

#errors2=np.zeros([(N_break-500),1])
#print('size err2',size(errors2[0:N_break-500]))
errors2= errors2[0:N_break-500]		#redefining till the braek point
errors = errors[0:N_break]
print('Nbreak',N_break)

#print('errors1:',errors1)
subplot(2,2,2)
#close()
xlabel('ITERATION->')
ylabel('ERRORS->')
n=np.linspace(1,N_break,num=N_break)
n1=np.linspace(1,500,num=500)
n2=np.linspace(501,N_break,num=N_break-500)

loglog(n[0::50],errors[0::50],color='red',marker='o',label='error points')  #PLOTTING EVERY 50TH DATA POINT

#FINDING LINEAR FIT  for log plot of first 500 iterations
log_n1= [float(math.log10(i)) for i in n1]
log_err1= [float(math.log10(i)) for i in errors1]
param= np.polyfit(log_n1,log_err1,1) #calculating parameters for linear fit
#print('ln_n1',type(ln_n1))
#p=np.poly1d(param)
print('param',param)

y=[i*(param[0])+param[1] for i in log_n1]   #LINEAR FIT in log10 terms
#print('y:',y)
#plot(errors1,label='<500')
#semilogy(errors2,label='>=500')


n1_pow= [ math.pow(10,i) for i in log_n1]
y_pow= [math.pow(10,i) for i in y]
loglog(n1_pow,y_pow,label='lin_fit <500')	#PLOTTING LOGLOG PLOT for <500 iterations
#print('lin_fit:',y,log_n1)


#FINDING EXPONENTIAL FIT FOR ITERATIONS >500


print('Nbreak',N_break)
ln_err2= [math.log(i) for i in errors2] #finding log values of error2
#Finding a linear fit in ln_err2 and n2

param2=  np.polyfit(n2,ln_err2,1)  #getting a,b values for y= ax +b

#print('param2:',param2)
y2=[i*(param2[0]) +param2[1] for i in n2] #obtaining linear fit 

 #if y=Ae^(Bx) what we have is log A -param2[1] and B-param2[0] x- n2  logy = y2
#y2_pow= [math.exp(i) for i in y2]
A=math.exp(param2[1])
B= param2[0]

#print('A',A)
#now to plot y=Ae^(Bx) we need A and B and n2 which we have
y_exp_fit= ([A*math.exp(B*i) for i in n2]) #finding exponential fit
plot(n2,y_exp_fit,color='blue',label='>=500') #PLOTTING THE EXPONENTIAL FIT
legend(loc='lower left')



#SEMI-LOG PLOT OF ERRORS
subplot(2,2,3)
xlabel('iterations->')
ylabel('Errors(semi log)-Entire')		#plotting semilog plot of errors in entire vector
semilogy(n,errors)

#CONTOUR PLOT OF POTENTIAL
subplot(2,2,4)
title('contour plot of final potential')
xlabel('x')
ylabel('y')
contour(X,Y,phi.transpose()) #obtaining equillibrium contour potential
scatter(X_org,Y_org,phi_org.transpose(),color='red',marker='o',linewidth=3)  #plotting the 1V points with red

show()
#SURFACE PLOT OF POTENTIAL
#close()
fig1=figure(2) #opens new figure
ax=p3.Axes3D(fig1) #Axes3D - function to make a surface plot
title('The 3-D surface plot of the potential')
ax.set_xlabel('x')
ax.set_ylabel('y')
ax.set_zlabel('Phi')
surf = ax.plot_surface(-Y,-X,phi, rstride=1,cstride=1, cmap= cm.jet)

show()

#OBTAINING PLOT OF CURRENT FLOW
fig2 = figure(3)
phi_t= phi.transpose()
Jx= np.zeros([Nx,Ny])
Jy= np.zeros([Nx,Ny])
phi=np.rot90(phi,k=1) #rotated in order to generate right orientation of plot from quiver function.
print(phi)
#phi=phi_t
#Jx[1:-1,1:int((Nx-1)/2) ]= 0.5*( phi[1:-1,0:int( (Nx-3)/2) ]  - phi[1:-1,2:int( (Nx+1)/2 )] ) # Jx = -d(phi)/dx
Jx[1:-1,1:-1] = -0.5*(phi[0:-2,1:-1]-phi[2:,1:-1]) #implementing equation for current density
Jy[1:-1,1:-1] = -0.5*(phi[1:-1,0:-2]-phi[1:-1,2:])

quiv=quiver(X,Y, Jx,Jy) #generaing quiver plot
xlabel('x')
ylabel('y')
scatter(X_org,Y_org,phi_org.transpose(),linewidth=5,color='red',marker='o')  #plotting the 1V points with red

show()


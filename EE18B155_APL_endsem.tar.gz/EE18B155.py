#PLEASE NOTE- While execution SCROLL UP THE COMMAND WINDOW for earlier outputs. Many list of numbers are printed to test for ratios,etc in the end of the assignment

#ASSUMPTION:
#Here Q is charge/m and C is F/m


#in order to find the capacitance we assume 1V is applied on the top, and then find the charge there, in order to find the charge we need to find Electric field distribution and del.E gives rho which in turn in this case gives lamda(line charge density) hence finally Q. and Q/1V = C


from pylab import*
import numpy as np
#import sympy as sy
import math
from scipy import*
#Relative permitivitty
e_r = 2.0
M=200
N=100

#function to solve laplace eqn and obtain phi(m,n):
def find_phi(M,N,delta_n, k, delta,N0):
	phi = np.zeros((M,N))
	err = np.zeros((N0,1))
	#Making the first row 0.5V
	phi[0,:]=1
	phi[M-1,:]=0
	phi[1:M,0]=0
	phi[1:M,N-1]=0
	i=0
	for i in range(N0):
		old_phi=phi.copy()
		
		
		#ASSUMPTION: k IS HEIGHT INDEX FROM TOP
		
		#To be computationally efficient we start solving the laplace eqn in first half and bottom half and the middle portion all at the same time
		
		#Top portion
		
		phi_top = phi[0:k+2,:] 
		#print(phi_top)
		#laplace eqns
		phi_top[1:-1,1:-1] = 0.25*(phi_top[1:-1,0:-2] +phi_top[1:-1,2:] +phi_top[0:-2,1:-1] +phi_top[2: , 1:-1])
		#boundary conditions
		# d(phi)/dn is zero on left side
		phi_top[1:-1,1]=phi_top[1:-1,0] 
		# d(phi)/dn is zero on right side
		phi_top[1:-1,N-2]=phi_top[1:-1,N-1]
		# d(phi)/dn is zero on top side
		phi_top[1, 1:-1 ] = phi_top[0, 1:-1 ]
		
		
		#For the middle layer(3rows):
		#phi_m = phi[k-1:k+2,:]
		#print(phi_m)
		#kth index row
		phi_k = phi[k:k+1,:] 
		#above layer
		phi_k_a = phi[k-1:k,:]
		#below layer 
		phi_k_b = phi[k+1:k+2,:] 
		
		phi_k = (e_r*phi_k_b +phi_k_a)/(1+e_r)
		
		
		#For the bottom layer
		
		phi_bot= phi[k+1:M,:]
		phi_bot[1:-1,1:-1] = 0.25*(phi_bot[1:-1,0:-2] +phi_bot[1:-1,2:] +phi_bot[0:-2,1:-1] +phi_bot[2: , 1:-1])
		#boundary conditions
		# d(phi)/dn is zero on left side
		phi_bot[1:-1,1]=phi_bot[1:-1,0] 
		# d(phi)/dn is zero on right side
		phi_bot[1:-1,N-2]=phi_bot[1:-1,N-1]
		# d(phi)/dn is zero on bottom side
		phi_bot[M-k-3:M-k-2,1:-1]=phi_bot[M-k-2:M-k-1,1:-1]
		
		#print(phi_bot)
		
		#reinitializing
		phi[0:k+2,:]=phi_top
		phi[k:k+1,:]=phi_k
		phi[k+1:M,:]= phi_bot
		
		err_old=err[i]
		err[i]=(abs(phi-old_phi)).max()
		#print('error:',err[i])
		if(err[i]<delta):
			break
	return(phi,i+1,err)
 

#height h
h=10#(in cm)
#Spacing
spac = 20.0/M  #(in cm)
#Calculating k from h
k=M-(int)(h/spac)
#misc. condition
if(k>=M-1):
	k=M-2
#ACCURACY
acc= 1e-9
phi,N_break,err=find_phi(M,N,spac,k,acc,500000)

#imshow(phi)
print('break iteration:',N_break)
print('accuracy:',acc)

#--------

x=np.linspace(0,10,num=N)		#Generating x array
y=np.linspace(20,0,num=M)		#Generating y array
X,Y = meshgrid(x,y)					#Making meshgrid of x and y coordinates

#----------




#In order to find Electric field at centre of mesh cells we can find the potential at centre and the centres of the adjacent squares by the averaging method.

#First finding potential for middle of squares
def Elect(phi1,p):
	Ex_new= np.zeros([M-1,N-1])
	Ey_new= np.zeros([M-1,N-1])
	#Finding E field for middle of squares (spac is in cm)
	Ex_new = -0.5*(phi1[0:-1,1:]+phi1[1:,1:]-phi1[0:-1,0:-1]-phi1[1:,0:-1])*(1e2/spac) #implementing equation for electric field
	Ey_new= -0.5*(phi1[0:-1,0:-1]+phi1[0:-1,1:]-phi1[1:,0:-1]-phi1[1:,1:])*(1e2/spac)
	#figure()
	#quiv=quiver(X,Y, Ex_new,Ey_new) #generaing quiver plot
	#xlabel('x')
	#ylabel('y')
	#title('quiver plot of electric field in middle of squares')
	#if(p==True):
	#	show()
	
	return(Ex_new,Ey_new)



#----------------





figure()

xlabel('x')
ylabel('y')
title('Contour plot of potential steady state')
scatter(X,Y,phi,color='red',marker='o',linewidth=3)  #plotting the 1V points with red
contourf(X,Y,phi,10)
show()
#resizing error
err = err[0:N_break]
#log plot of errors and extrapolation till inf
figure()
grid(True)
n= np.arange(N_break)
title('Error vs iteration (log log plot)')
xlabel('n')
ylabel('err')
loglog(n,err,Marker='o',color='red',label='error[k]')
legend(loc='upper right')
ylabel('err')
show()

figure()
grid(True)
n= np.arange(N_break)
title('Error vs iteration (semilog plot)')
xlabel('n')
ylabel('err')

semilogy(n,err,Marker='o',color='blue',label='error[k]')
legend(loc='upper right')
ylabel('err')
show()

#Extrapolation of errors till inf- basically finding parameters of exponential
log_n= [float(math.log(abs(i))) for i in n[1:]]
log_err= [float(math.log(abs(i))) for i in err[1:]]
param= np.polyfit(log_n,log_err,1) #calculating parameters for linear fit
A = (float)(math.exp(param[1]))
B = (float)(param[0])
print('The extrapoation in error is of the form:',A,'*exp(',B,'*n)')

#from lab assignment 5, we see that total error can be expressed as -(A/B)*exp(B(N+0.5))
#now as per this, we can say that delta should be less than this value.

#calculating total error
tot_err=  -((A/B)*math.exp(B*(N_break+0.5)))
#Now, delta should be more than this error, because this is the real error after N iterations
print('Total error calculated after integration plugging in number of iterations:',tot_err) 



#Computing Electric fields
Ex,Ey=Elect(phi,True)
#figure()
#grid(True)
#quiv=quiver(X,Y, Ex,Ey) #generaing quiver plot
#title('quiver plot of Electric field')
#xlabel('x')
#ylabel('y')

show()

#--------




#---------


#Now we can find capacitance/m for that height now that we have E field variation on the top

#We can use the Electric field at the top to find the charge/m. This is because Electric field outside the tank has to be zero which means the charge/m depends only on the field inside. After finding the charge/m Q hence capacitance/m  for the height h is Q/1V = C

#Now we need to sum up Electric field on top acc to- Q = -sigma( epsilon0*E_n*spacing)  E_n-E normal

epsilon0=  8.85e-14  #(F/cm)
Lx = 10 #(in cm)
Ly = 20 #in cm
#charge for 1V or cap

#running iteration for h/Ly = 0.1->0.9
Q_arr=[]
Q_arr2=[]
x= linspace(0.1,0.9,num=9)

for c in range(1,10):
	
	#code to calculate k
	h1=20*(0.1*c)
	k1=M-(int)(h1/spac)
	if(k1>=M-1):
		k1=M-2

	
	#returns phi	
	phi1,N_break1,err1=find_phi(M,N,spac,k1,acc,500000)
	
	
	#implementing equation for electric field
	Ex1,Ey1=Elect(phi1,False)
	#print(Ex1,Ey1)
	#calulcating charge/m Q_top
	Q=0
	#print(Ey1[1,:])
	for i in Ey1[1,:]:
		Q+= epsilon0*i*spac
 
	
	Q=-Q #opposite normal 
	Q_arr.append(Q)
	#Calculating charge/m Q_fluid
	Q_f=0
	c1=1
	
	#Left wall and right wall twice because of symmetry
	for i in Ex1[k1:M-1,c1]:
		Q_f+=2*epsilon0*i*spac*e_r
	#print('left wall')
	
	#Right wall
	#for i in Ex1[k1:M-1,N-c1-2]:
	#	Q_f+= epsilon0*i*spac*e_r
	#print('right wall')
	
	#Bottom 
	for i in Ey1[M-c1-2,:]:
		Q_f+=epsilon0*i*spac*e_r
	#print('bottom')
	print('Iteration:',c)
	print('Qfluid:',Q_f,'C/m')
	Q_arr2.append(Q_f)
	
	print('Qtop for h:',h1,'cm is:',Q,' C/m')

figure()
grid(True)
xlabel('h/Ly->')
ylabel('Qtop (C/m)->')
title('plot of Qtop vs h/Ly')
plot(x,Q_arr,Marker='o',Color='Red',label='Qtop(h/Ly)')
legend(loc = 'upper left')													#Plotting Qtop and Qfluid
show()

figure()
grid(True)
xlabel('h/Ly->')
ylabel('Qfluid (C/m) ->')
title('plot of Qfluid vs h/Ly')
plot(x,Q_arr2,Marker='o',Color='blue',label='Qfluid(h/Ly)')
legend(loc = 'upper left')
show()







#For h=10cm
#Obtaining Dn at m=k
#We have to prove epsilon_r*E1_n = E0_n
#or we can find max absolute error in between the two normal displacement vectors 

#print(Ey_new[k,:],Ex_new[k,:])
print('\nRatio of Dn1 and Dn2 at interface:')
for i in range(N-1):
	print((Ey[k-1,i]/(e_r*Ey[k,i])))
print('Hence, continuity is satisfied\n')




#Change in angle of E field at m=k
# We can take theta as tan-1(Ey/Ex) and then find sin(theta1) as an array and (epsilon_r)^0.5*sin(theta2) as another array and compare the ratio. This is from n1*sin(theta1)=n2*sin(theta2) and theta here is angle with horizontal and (epsilon_r)^0.5 is refractive index hence, final relation is  sin(theta1)=(epsilon_r^0.5)*sin(theta2)

#Air

theta1 = [math.atan( (Ey[k-1,i])/(Ex[k-1 ,i])) for i in range(N-1)]

#Dielectric
theta2 = [math.atan( (Ey[k,i])/(Ex[k ,i])) for i in range(N-1)]


#print('\nChange in angle is(in degrees):')
change=[]
for i in range(N-1):
	#print(180*(theta1[i]-theta2[i])/pi)
	change.append(180*(theta1[i]-theta2[i])/pi)
figure()
grid(True)
n = linspace(0.5*spac,Lx-0.5*spac,num=N-1)
xlabel('x->')
ylabel('Angle(degrees)->')
title('Plot of angle change across interface->')
plot(n,change,Marker='o',Color='Red',label ='Ang. change')
legend(loc='upper right')
show()

#for snells law
sin_theta1= [math.sin(i) for i in theta1]
sin_theta2= [math.sin(i) for i in theta2]

print('\nRatio of sin(theta1)/(epsilonr^0.5)*sin(theta2):')
ratio=[(sin_theta1[i]/((math.pow(e_r,0.5))*sin_theta2[i])) for i in range(N-1) ]
print(ratio)

#We see that its not giving 1 , this is obvious given that its a static situation where we can't apply snells law to just static electric fields. Also this calculation doesn't give the solution for fields under an AC source.



#In order to determine h from f we can find C from f and hence,we need to find the capacitance as a function of h to determine the h.

#We know Qtop as a function of h we need to polyfit and see what function turns out.

z = np.polyfit(x,Q_arr,2)
y = z[2] + z[1]*x + z[0]*np.multiply(x,x) 
figure()
grid(True)
ylabel('C (F/m) ->')
xlabel('h/Ly->')
title('Plot of predicted values for C ')
plot(x,y,Marker='o',Color='red',label='predicted points')
legend(loc= 'upper left')
show()

#So after this we can fit in any value of capacitance/m in order to get h/Ly. In this case, its just 10 points, to increase accuracy we can increase number of points and find out the corresponding h value.








